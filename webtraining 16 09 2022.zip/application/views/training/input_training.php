 <div>
     <?= $this->session->flashdata('msg'); ?>
 </div>

 <form id="formTraining" method="POST" action="<?= base_url(); ?>training/simpantraining">
     <input type="hidden" id="cekKaryawan">
     <div class="row">
         <div class="col-md-12">
             <div class="card">
                 <div class="card-header">
                     <h2 class="card title"> Data Training </h2>
                 </div>
                 <div class="card-body">
                     <input type="hidden" readonly name="no_training" id="no_training">
                     <div class="input-icon mb-3">
                         <span class="input-icon-addon">
                             <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                 <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                 <path d="M3 19a9 9 0 0 1 9 0a9 9 0 0 1 9 0" />
                                 <path d="M3 6a9 9 0 0 1 9 0a9 9 0 0 1 9 0" />
                                 <line x1="3" y1="6" x2="3" y2="19" />
                                 <line x1="12" y1="6" x2="12" y2="19" />
                                 <line x1="21" y1="6" x2="21" y2="19" />
                             </svg>
                         </span>
                         <input type="text" class="form-control" name="training" id="training"
                             placeholder="Judul Training" autocomplete="off">
                     </div>
                     <div class="input-icon mb-3">
                         <span class="input-icon-addon">
                             <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                 <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                 <circle cx="12" cy="7" r="4" />
                                 <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                             </svg>
                         </span>
                         <input type="text" class="form-control" name="trainer" id="trainer" placeholder="Nama Trainer"
                             autocomplete="off">
                     </div>
                     <div class="input-icon mb-3">
                         <span class="input-icon-addon">
                             <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                 <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                 <rect x="4" y="5" width="16" height="16" rx="2" />
                                 <line x1="16" y1="3" x2="16" y2="7" />
                                 <line x1="8" y1="3" x2="8" y2="7" />
                                 <line x1="4" y1="11" x2="20" y2="11" />
                                 <line x1="11" y1="15" x2="12" y2="15" />
                                 <line x1="12" y1="15" x2="12" y2="18" />
                             </svg>
                         </span>
                         <input type="text" class="form-control" value="<?= date("Y-m-d"); ?>" name="tgltraining"
                             id="tgltraining" placeholder="Tangggal Training">
                     </div>
                     <div class="col-md-12">
                         <div class="input-icon mb-3">
                             <span class="input-icon-addon">
                                 <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                     viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                     stroke-linecap="round" stroke-linejoin="round">
                                     <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                     <circle cx="12" cy="7" r="4" />
                                     <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                                 </svg>
                             </span>
                             <input type="hidden" value="<?= $this->session->userdata('id_user'); ?>" name="id_user"
                                 id="id_user">
                             <input type="text" readonly value="<?= $this->session->userdata('id_user')  . " - " .
                                                                    $this->session->userdata('nama_lengkap'); ?>"
                                 class="form-control" name="username" id="username" placeholder="ID User">

                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>

     <div class="row mt-3">
         <div class="col-md-12">
             <div class="card">
                 <div class="card-header">
                     <h2 class="card title"> Data Karyawan</h2>
                 </div>
                 <div class="card-body">
                     <div class="row">
                         <div class="col-md-4">
                             <div class="input-icon mb-3">
                                 <span class="input-icon-addon">
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                         viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                         stroke-linecap="round" stroke-linejoin="round">
                                         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                         <circle cx="12" cy="7" r="4" />
                                         <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                                     </svg>
                                 </span>
                                 <input type="text" readonly class="form-control" name="kodekaryawan" id="kodekaryawan"
                                     placeholder="Kode Karyawan">
                             </div>
                         </div>

                         <div class="col-md-4">
                             <div class="input-icon mb-3">
                                 <span class="input-icon-addon">
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                         viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                         stroke-linecap="round" stroke-linejoin="round">
                                         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                         <circle cx="12" cy="7" r="4" />
                                         <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                                     </svg>
                                 </span>
                                 <input type="text" readonly class="form-control" name="namakaryawan" id="namakaryawan"
                                     placeholder="Nama Karyawan">
                             </div>
                         </div>
                         <div class="col-md-4">
                             <div class="input-icon mb-3">
                                 <span class="input-icon-addon">
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                         viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                         stroke-linecap="round" stroke-linejoin="round">
                                         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                         <rect x="4" y="4" width="6" height="6" rx=" 1" />
                                         <rect x="14" y="4" width="6" height="6" rx="1" />
                                         <rect x="4" y="14" width="6" height="6" rx="1" />
                                         <rect x="14" y="14" width="6" height="6" rx="1" />
                                     </svg>
                                 </span>
                                 <input type="text" readonly class="form-control" name="jabatan" id="jabatan"
                                     placeholder="Jabatan">
                             </div>
                         </div>
                     </div>
                     <div class="row">
                         <div class="col-md-4">
                             <div class="input-icon mb-3">
                                 <span class="input-icon-addon">
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                         viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                         stroke-linecap="round" stroke-linejoin="round">
                                         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                         <rect x="4" y="4" width="6" height="6" rx=" 1" />
                                         <rect x="14" y="4" width="6" height="6" rx="1" />
                                         <rect x="4" y="14" width="6" height="6" rx="1" />
                                         <rect x="14" y="14" width="6" height="6" rx="1" />
                                     </svg>
                                 </span>
                                 <input type="text" readonly class="form-control" name="departement" id="departement"
                                     placeholder="Departement">
                             </div>
                         </div>
                         <div class="col-md-4">
                             <div class="input-icon mb-3">
                                 <span class="input-icon-addon">
                                     <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                         viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                         stroke-linecap="round" stroke-linejoin="round">
                                         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                         <rect x="3" y="5" width="18" height="14" rx="2" />
                                         <polyline points="3 7 12 13 21 7" />
                                     </svg>
                                 </span>
                                 <input type="text" readonly class="form-control" name="email" id="email"
                                     placeholder="Email">
                             </div>
                         </div>

                         <div class="col-md-4">
                             <div class="input-icon mb-3">
                                 <select name="ket" id="ket" class="form-select">
                                     <option value="">Pilih Keterangan </option>
                                     <option value="lulus"> Lulus </option>
                                     <option value="tidak lulus"> Tidak Lulus</option>
                                 </select>
                             </div>
                         </div>

                     </div>
                     <div class="col-md-12 mb-4">
                         <a href="#" id="tambahkaryawan" class="btn btn-secondary w-100">
                             Kirim Data
                         </a>
                     </div>
                     <div class="card">
                         <table id="tabelkaryawan" class="table table-bordered table-striped">
                             <thead>
                                 <tr>
                                     <th> NO. </th>
                                     <th> KODE KARYAWAN </th>
                                     <th> NAMA KARYAWAN </th>
                                     <th> JABATAN </th>
                                     <th> DEPARTEMENT </th>
                                     <th> EMAIL </th>
                                     <th> KETERANGAN </th>
                                     <th> AKSI </th>
                                 </tr>
                             </thead>
                             <tbody id="loaddatakaryawan">
                             </tbody>
                         </table>
                     </div>
                     <div class="row">
                         <button type="submit" class="btn btn-primary">
                             <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                 <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                 <line x1="10" y1="14" x2="21" y2="3" />
                                 <path
                                     d="M21 3l-6.5 18a0.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a0.55 .55 0 0 1 0 -1l18 -6.5" />
                             </svg>
                             Simpan Data </button>
                     </div>
                     <div class="modal modal-blur fade" id="modalkaryawan" tabindex="-1" role="dialog"
                         aria-hidden="true">
                         <div class="modal-dialog modal-full-width modal-dialog-centered" role="document">
                             <div class="modal-content">
                                 <div class="modal-header">
                                     <h5 class="modal-title"> Data Karyawan </h5>
                                     <button type="button" class="btn-close" data-dismiss="modal"
                                         aria-label="Close"></button>
                                 </div>
                                 <div class="modal-body">
                                     <table id="tabeldatakaryawan" class="table table-striped table-bordered">
                                         <thead>
                                             <tr>
                                                 <th> NO. </th>
                                                 <th> KODE KARYAWAN </th>
                                                 <th> NAMA KARYAWAN</th>
                                                 <th> TANGGAL LAHIR </th>
                                                 <th> ALAMAT </th>
                                                 <th> JABATAN</th>
                                                 <th> DEPARTEMENT</th>
                                                 <th> TELEPON</th>
                                                 <th> EMAIL </th>
                                                 <th>AKSI</th>
                                         </thead>
                                         <tbody>
                                             <?php
                                                $num = 1;
                                                foreach ($karyawan as $k) { ?>
                                             <tr class="text-center">
                                                 <td> <?= $num; ?></td>
                                                 <td> <?= $k->kode_karyawan; ?></td>
                                                 <td> <?= $k->nama; ?> </td>
                                                 <td> <?= $k->ttl; ?> </td>
                                                 <td> <?= $k->alamat; ?> </td>
                                                 <td> <?= $k->jabatan; ?> </td>
                                                 <td> <?= $k->departement; ?> </td>
                                                 <td> <?= $k->telepon; ?> </td>
                                                 <td> <?= $k->email; ?> </td>
                                                 <td>
                                                     <a href="#" class="btn btn-primary pilihkaryawan"
                                                         data-kodekaryawan="<?= $k->kode_karyawan; ?>"
                                                         data-jabatan="<?= $k->jabatan; ?>"
                                                         data-departement="<?= $k->departement; ?>"
                                                         data-email="<?= $k->email; ?>" data-namakaryawan="<?= $k->nama; ?>
                                                         "> Pilih
                                                     </a>
                                                 </td>
                                             </tr> >
                                             <?php $num++;
                                                } ?>
                                         </tbody>
                                     </table>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     </div>
     </div>
 </form>

 <script>
document.addEventListener("DOMContentLoaded", function() {
    flatpickr(document.getElementById('tgltraining'), {});
});
$("#tabeldatakaryawan").DataTable();
 </script>

 <script>
$("#formTraining").submit(function() {
    var training = $("#training").val();
    var trainer = $("#trainer").val();
    var tgltraining = $("#tgltraining").val();

    if (training == "") {
        swal("Duh!!!", "Nama training belum diisi", "warning");
        return false;
    } else if (trainer == "") {
        swal("Duh!!!", "Nama trainer belum diisi", "warning");
        return false;
    } else if (tgltraining == "") {
        swal("Duh!!!", "Tanggal training belum diisi", "warning");
        return false;
    } else if (ket == "") {
        swal("Duh!!!", "Keterangan belum diisi", "warning");
        return false;
    } else if (kodekaryawan == "") {
        swal("Duh!!!", "Data Karyawan belum diisi", "warning");
        return false;
    } else {
        return true;
    }
});
 </script>

 <script>
function cekKaryawan() {
    $.ajax({
        type: 'POST',
        url: '<?= base_url(); ?>training/cekKaryawan',
        cache: false,
        success: function(respond) {
            $("#cekKaryawan").val(respond);
        }
    });
}
 </script>

 <script>
function loaddatakaryawan() {
    var id_user = $("#id_user").val();
    $.ajax({
        type: 'POST',
        url: '<?= base_url(); ?>training/getDataKaryawanTemp',
        data: {
            id_user: id_user
        },
        cache: false,
        success: function(respond) {
            $("#loaddatakaryawan").html(respond);
        }
    });
}

loaddatakaryawan();
cekKaryawan();


$("#kodekaryawan").click(function() {
    $("#modalkaryawan").modal("show");
});

$("#tabelkaryawan").DataTable();

$(".pilihkaryawan").click(function() {
    var kodekaryawan = $(this).attr("data-kodekaryawan");
    var namakaryawan = $(this).attr("data-namakaryawan");
    var jabatan = $(this).attr("data-jabatan");
    var departement = $(this).attr("data-departement");
    var email = $(this).attr("data-email");
    $("#kodekaryawan").val(kodekaryawan);
    $("#namakaryawan").val(namakaryawan);
    $("#jabatan").val(jabatan);
    $("#departement").val(departement);
    $("#email").val(email);
    $("#modalkaryawan").modal("hide");
});

// add karyawan mengg. ajax
$("#tambahkaryawan").click(function() {
    var kodekaryawan = $("#kodekaryawan").val();
    var namakaryawan = $("#namakaryawan").val();
    var jabatan = $("#jabatan").val();
    var departement = $("#departement").val();
    var email = $("#email").val();
    var ket = $("#ket").val();
    var id_user = $("#id_user").val();

    if (training == "") {
        swal("Duh!!!", "Nama training belum diisi", "warning");
    } else if (trainer == "") {
        swal("Duh!!!", "Nama trainer belum diisi", "warning");
    } else if (tgltraining == "") {
        swal("Duh!!!", "Tanggal training belum diisi", "warning");
    } else if (id_user == "") {
        swal("Duh!!!", "ID User belum diisi", "warning");
    } else if (ket == "") {
        swal("Duh!!!", "Keterangan belum diisi", "warning");
    } else if (kodekaryawan == "") {
        swal("Duh!!!", "Data Karyawan belum diisi", "warning");
    } else {
        $.ajax({
            type: 'POST',
            url: '<?= base_url(); ?>training/simpankaryawantemp',
            data: {
                kode_karyawan: kodekaryawan,
                nama: namakaryawan,
                jabatan: jabatan,
                departement: departement,
                email: email,
                ket: ket,
                id_user: id_user,
            },
            cache: false,
            success: function(respond) {
                if (respond == 1) {
                    swal("Oopss", "Data sudah ada", "warning");
                } else {
                    loaddatakaryawan();
                }
            }
        });
    }
});
 </script>